#include "eeg_cmd_parser.h"
#include "signal_analysis.h"
#include "eeg_direction_collect.h"
#include "eeg_direction_infer.h"
#include "eeg_direction_feature.h"
#include "eeg_fft.h"
#include "Message_Parser.h"
#include "Serial.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

extern uint8_t g_eeg_app_mode;
extern uint8_t g_ipc_diag_enable;
extern uint8_t g_posture_diag_enable;
extern volatile uint32_t g_icm42605_ms_tick;

#define RESP(fmt, ...) do { \
    Serial_Printf(SERIAL_PORT_DEBUG, fmt, ##__VA_ARGS__); \
    Serial_Printf(SERIAL_PORT_WIFI, fmt, ##__VA_ARGS__); \
} while(0)

#define RETRY_BUF_SIZE 128
#define RETRY_TIMEOUT_MS 300

static char s_retry_buf[RETRY_BUF_SIZE];
static uint8_t s_retry_seq = 0;
static uint8_t s_retry_count = 0;
static uint8_t s_retry_max = 10;
static uint32_t s_retry_send_tick = 0;

uint8_t Retry_GetSeq(void)
{
    return s_retry_seq + 1u;
}

void Retry_Store(const char *msg)
{
    s_retry_seq++;
    strncpy(s_retry_buf, msg, RETRY_BUF_SIZE - 1);
    s_retry_buf[RETRY_BUF_SIZE - 1] = '\0';
    s_retry_count = 0;
    s_retry_max = 10;
    s_retry_send_tick = g_icm42605_ms_tick;
}

void Retry_StoreEx(const char *msg, uint8_t max_count)
{
    s_retry_seq++;
    strncpy(s_retry_buf, msg, RETRY_BUF_SIZE - 1);
    s_retry_buf[RETRY_BUF_SIZE - 1] = '\0';
    s_retry_count = 0;
    s_retry_max = max_count;
    s_retry_send_tick = g_icm42605_ms_tick;
}

void Retry_Tick(void)
{
    if (s_retry_buf[0] == '\0') return;
    if (s_retry_count >= s_retry_max) {
        s_retry_buf[0] = '\0';
        return;
    }
    uint32_t elapsed = g_icm42605_ms_tick - s_retry_send_tick;
    if (elapsed >= RETRY_TIMEOUT_MS) {
        s_retry_count++;
        s_retry_send_tick = g_icm42605_ms_tick;
        Serial_Printf(SERIAL_PORT_WIFI, "%s", s_retry_buf);
        Serial_Printf(SERIAL_PORT_DEBUG, "[RETRY:%u] %s", s_retry_count, s_retry_buf);
    }
}

static void Retry_Ack(uint8_t seq)
{
    if (seq == s_retry_seq && s_retry_buf[0] != '\0') {
        s_retry_buf[0] = '\0';
    }
}

void Parse_CommandEx(const char *cmd, const char *source)
{
    char clean_cmd[64];
    strncpy(clean_cmd, cmd, sizeof(clean_cmd) - 1);
    clean_cmd[sizeof(clean_cmd) - 1] = '\0';
    size_t len = strlen(clean_cmd);
    while (len > 0 && (clean_cmd[len-1] == '\r' || clean_cmd[len-1] == '\n')) {
        clean_cmd[len-1] = '\0';
        len--;
    }

    Serial_Printf(SERIAL_PORT_DEBUG, "RX[%s]: %s\r\n", source, clean_cmd);
    Serial_Printf(SERIAL_PORT_WIFI, "RX[%s]: %s\r\n", source, clean_cmd);

    if (strncmp(clean_cmd, "ACK,", 4) == 0) {
        uint8_t ack_seq = (uint8_t)atoi(clean_cmd + 4);
        Retry_Ack(ack_seq);
        return;
    }

    if (strcmp(clean_cmd, "MODE,TRAIN") == 0) {
        g_work_mode = WORK_MODE_TRAIN;
        g_trial_state = TRIAL_IDLE;
        g_paused = 0;
        Direction_ResetRestBaseline();
        RESP("READY_TRAIN\r\n");
        return;
    }
    if (strcmp(clean_cmd, "MODE,TEST") == 0) {
        g_work_mode = WORK_MODE_TEST;
        g_trial_state = TRIAL_IDLE;
        g_paused = 0;

        EEG_FFT_ResetInferState();
        RESP("READY_TEST\r\n");
        return;
    }
    if (strncmp(clean_cmd, "MODE,SET,", 9) == 0) {
        int mode = atoi(clean_cmd + 9);
        if (mode == EEG_APP_MODE_COLLECT || mode == EEG_APP_MODE_INFER || mode == EEG_APP_MODE_COLLECT_CSP) {
            g_eeg_app_mode = (uint8_t)mode;
            if (mode == EEG_APP_MODE_COLLECT || mode == EEG_APP_MODE_COLLECT_CSP) {
                g_ipc_diag_enable = 0;
            }
            RESP("MODE_SET_OK,%d\r\n", mode);
            dir_phase = DIR_PHASE_REST;
            dir_phase_row_count = 0;
            dir_skip_row_count = 0;
            dir_round_count = 0;
            csp_collect_row_tick = 0;
            csp_window_id = 0;
        } else {
            RESP("ERROR,INVALID_MODE\r\n");
        }
        return;
    }
    if (strncmp(clean_cmd, "TRIAL,", 6) == 0) {
        if (g_work_mode != WORK_MODE_TRAIN) {
            RESP("ERROR,NOT_TRAIN_MODE\r\n");
            return;
        }
        if (g_trial_state == TRIAL_RUNNING) {
            RESP("ERROR,BUSY\r\n");
            return;
        }
        const char *side = clean_cmd + 6;
        if (strcmp(side, "LEFT") == 0) {
            g_trial_label = DIR_LABEL_LEFT;
        } else if (strcmp(side, "RIGHT") == 0) {
            g_trial_label = DIR_LABEL_RIGHT;
        } else {
            RESP("ERROR,INVALID_SIDE\r\n");
            return;
        }
        g_trial_state = TRIAL_RUNNING;
        g_trial_row_count = 0;
        g_paused = 0;
        Direction_ResetTaskZero();
        RESP("TASK,%s,start\r\n", (g_trial_label==DIR_LABEL_LEFT)?"LEFT":"RIGHT");
        return;
    }
    if (strcmp(clean_cmd, "STOP") == 0) {
        g_work_mode = WORK_MODE_IDLE;
        g_trial_state = TRIAL_IDLE;
        g_paused = 0;
        g_eeg_app_mode = EEG_APP_MODE_COLLECT;
        EEG_FFT_ResetInferState();
        Direction_Infer1sReset();
        RESP("TASK,STOPPED\r\n");
        return;
    }
    if (strcmp(clean_cmd, "STATUS") == 0) {
        RESP("STATUS,mode=%d,trial=%d,row=%d\r\n",
                      g_work_mode, g_trial_state, g_trial_row_count);
        return;
    }
    if (strcmp(clean_cmd, "IPCDIAG,ON") == 0) {
        g_ipc_diag_enable = 1;
        RESP("IPCDIAG,ON\r\n");
        return;
    }
    if (strcmp(clean_cmd, "IPCDIAG,OFF") == 0) {
        g_ipc_diag_enable = 0;
        RESP("IPCDIAG,OFF\r\n");
        return;
    }
    if (strcmp(clean_cmd, "POSTURE,ON") == 0) {
        g_posture_diag_enable = 1;
        RESP("POSTURE,ON\r\n");
        return;
    }
    if (strcmp(clean_cmd, "POSTURE,OFF") == 0) {
        g_posture_diag_enable = 0;
        RESP("POSTURE,OFF\r\n");
        return;
    }
    if (strncmp(clean_cmd, "DISPLAY_CFG,", 12) == 0) {
        const char *p = clean_cmd + 12;
        int wca = -1, wta = -1, wcb = -1, wtb = -1, sta = -1, stb = -1;
        while (*p) {
            if (strncmp(p, "WAVE_CH_A=", 10) == 0) { wca = atoi(p + 10); }
            else if (strncmp(p, "WAVE_TYPE_A=", 12) == 0) { wta = atoi(p + 12); }
            else if (strncmp(p, "WAVE_CH_B=", 10) == 0) { wcb = atoi(p + 10); }
            else if (strncmp(p, "WAVE_TYPE_B=", 12) == 0) { wtb = atoi(p + 12); }
            else if (strncmp(p, "SPEC_TYPE_A=", 12) == 0) { sta = atoi(p + 12); }
            else if (strncmp(p, "SPEC_TYPE_B=", 12) == 0) { stb = atoi(p + 12); }
            const char *next = strchr(p, ',');
            if (next == NULL) break;
            p = next + 1;
        }
        if (wca >= 0 && wca < DISPLAY_MAX_CH) g_display_config.wave_ch[0] = (uint8_t)wca;
        if (wta >= 0 && wta <= 2) g_display_config.wave_type[0] = (uint8_t)wta;
        if (wcb >= 0 && wcb < DISPLAY_MAX_CH) g_display_config.wave_ch[1] = (uint8_t)wcb;
        if (wtb >= 0 && wtb <= 2) g_display_config.wave_type[1] = (uint8_t)wtb;
        if (sta >= 0 && sta <= 2) g_display_config.spec_type[0] = (uint8_t)sta;
        if (stb >= 0 && stb <= 2) g_display_config.spec_type[1] = (uint8_t)stb;
        RESP("DISPLAY_CFG_OK,WCA=%u,WTA=%u,WCB=%u,WTB=%u,STA=%u,STB=%u\r\n",
             (unsigned)g_display_config.wave_ch[0],
             (unsigned)g_display_config.wave_type[0],
             (unsigned)g_display_config.wave_ch[1],
             (unsigned)g_display_config.wave_type[1],
             (unsigned)g_display_config.spec_type[0],
             (unsigned)g_display_config.spec_type[1]);
        return;
    }
    RESP("ERROR,UNKNOWN_CMD\r\n");
}
